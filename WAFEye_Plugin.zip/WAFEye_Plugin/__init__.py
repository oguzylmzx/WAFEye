import os
import importlib

def load_plugins():
    plugins = {}
    plugin_folder = os.path.dirname(__file__)
    for file in os.listdir(plugin_folder):
        if file.endswith(".py") and file != "__init__.py":
            module_name = file[:-3]
            try:
                module = importlib.import_module(f"{__name__}.{module_name}")
                plugins[module_name] = module
            except Exception as e:
                print(f"[!] Plugin yüklenemedi: {module_name}, Hata: {e}")
    return plugins
